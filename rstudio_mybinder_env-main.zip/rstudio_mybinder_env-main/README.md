![Binder](https://github.com/${GITHUB_REPOSITORY}/workflows/Binder/badge.svg)

This is a template environment, pre-configured to run Github Classroom assessments.

<a href="https://mybinder.org/v2/gh/profrobwells/rstudio_mybinder_env/main?urlpath=git-pull%3Frepo%3Dhttps%253A%252F%252Fgithub.com%252F${profrobwells}%252F${rstudio_mybinder_env}%26targetPath%wellsdata-classroom-test%26urlpath%3Drstudio%252F%26branch%3Dmain">
  <img src="https://mybinder.org/badge_logo.svg" alt="Launch Binder"/>
</a>
